﻿#************************************************
# DC_Ex_ExBPAcmd.ps1
# Version 1.0.0
# Date: 04-27-2012
# Author: Brian Prince - brianpr@microsoft.com
# Description: This script runs ExBPAcmd.exe to generate health check for Organization, Administrative Group and local Exchange 2007 or 2010 Server.
#************************************************
# 2019-03-17 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

if($debug -eq $true){[void]$shell.popup("Running DC_Ex_ExBPAcmd.ps1")}

Import-LocalizedData -BindingVariable ExBPAcmdStrings 
Write-DiagProgress -Activity $ExBPAcmdStrings.ID_Ex_ExBPAcmdAct -Status $ExBPAcmdStrings.ID_Ex_ExBPAcmdStat

$exchangeServer = Get-ExchangeServerLocalCached
if ($exchangeServer)
{
	$bpaOutFileName = join-path $pwd.path ($exchangeServer.Name + "_" + (Get-Date -uformat "%Y%m%d.%H%M") + "_ExBPA.xml")
	$bpaFilesToCollect = ($bpaOutFileName + "*")
	$bpaArgs = "Server=" + $exchangeServer.Name + ",Organization,AdminGroup=Exchange Administrative Group (FYDIBOHF23SPDLT),Health"
	$bpaPath = "`"" + $global:exBin + "exbpacmd.exe" + "`""
	$cmdToRun = " /c `"$bpaPath -dat "
	$cmdToRun = $cmdToRun + "`"" + $bpaOutFileName + "`"" + " -to 120 -r "
	$cmdToRun = $cmdToRun + "`"" + $bpaArgs + "`"" + " > nul`""
	
	#Write-DiagProgress -Activity $GetExchDataStrings.ID_Ex_ExBPAcmdAct -Status $GetExchDataStrings.ID_Ex_ExBPAcmdStat
	("Running ExBPAcmd.exe with the following command line: " + $cmdToRun) | WriteTo-StdOut
	if($debug -eq $true){[void]$shell.popup("Running ExBPAcmd.exe with the following command line: " + $cmdToRun)}
	BackgroundProcessCreate -ProcessName "cmd.exe" -Arguments $cmdToRun -collectfiles $true -filesToCollect $bpaFilesToCollect -fileDescription $ExBPAcmdStrings.ID_Ex_ExBPAcmdFileDescription -sectionDescription ($ExBPAcmdStrings.ID_Ex_ExBPAcmdReportSection) -BackgroundExecution

}