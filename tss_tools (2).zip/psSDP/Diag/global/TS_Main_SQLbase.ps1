﻿#_#$debug = $false

# Load Common Library:
. ./utils_cts.ps1

# Load the SQL Common Library
. ./utils_DSD.ps1

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {

	Run-DiagExpression .\DC_BasicSystemInformation.ps1

	# DanSha : Working to replace MSINFO32 with SYSTEMINFO.EXE
	# Start MSINFO32 first since it takes the longest to run and runs as a background task
	#
	#_#Run-DiagExpression .\DC_MSInfo.ps1

	# TCP/IP port usage by application
	#
	#_#Run-DiagExpression .\TS_PortUsage.ps1

	# Collect Windows Application and System Evenlogs in TXT, CSV, EVT format
	# EVT and EVTX formats required to enable UDE rules processing to avoid the complexity of dealing with local languages
	#
	$EventLogNames = "System", "Application"
	$OutputFormats = "TXT", "CSV", "EVT", "EVTX"
	Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -OutputFormats $OutputFormats $Days 30

	#  Collect Dr. Watson WER (Windows Error Reporting) minidumps
	#  Explicity entry is required for this collector because there is no default command in the include.xml
	#
	Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -MaxFilesToCopy 3 -MaximumAge 30 -MaxFileSize 25 -CopyOnlyUserDumpsFrom 'sqlservr.exe'

	# Collect cluster registry keys.  
	# Explicit entry is required for this collector because no include.xml exists for this collector so an explicit entry in TS_Main is required
	#
	Run-DiagExpression .\DC_RegistryCluster.ps1

	# ChkSym
	# Looking to gain efficiencies wherever we can so eliminating SPOOL which we were previously including by allowing collection to default to ALL
	$range = "ProgramFilesSys", "Drivers", "System32DLL", "System32Exe", "System32SYS", "iSCSI", "Process", "RunningDrivers", "Cluster"
	Run-DiagExpression .\DC_ChkSym.ps1 -range $range
	
		# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_SQLbase.ps1

	EndDataCollection


} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

