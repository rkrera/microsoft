﻿# Load Common Library
# Load Reporting Utilities
#_#$debug = $false

# Load Common Library:
. ./utils_cts.ps1
<# Load the SQL Common Library
. ./utils_DSD.ps1	#SQL
. ./TS_RemoteSetup.ps1	#Cluster,HyperV,Remote
. ./utils_Exchange.ps1
#>

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {

	Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyMachineMemoryDump -CopyTDRDumps

	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_ALL.ps1
	EndDataCollection

} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
