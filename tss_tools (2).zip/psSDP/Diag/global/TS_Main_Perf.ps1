﻿# Load Common Library
# Load Reporting Utilities
#_#$debug = $false

. ./utils_cts.ps1

$FirstTimeExecution = FirstTimeExecution

if ($FirstTimeExecution) {
	
	#_#Run-DiagExpression .\TS_QueueEventLogRules.ps1
	Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps -MaxFileSize 300 -CopyUserDumps -CopyWERFulldumps

	.\TS_AutoAddCommands_Perf.ps1
	#_#Run-DiagExpression  .\TS_ProcessEventLogRules.ps1

	EndDataCollection
} else {
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
