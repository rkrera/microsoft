﻿Import-LocalizedData -BindingVariable Strings

Function GetWin32OSFromRemoteSystem([string] $MachineName)
{
	trap [Exception] 
	{
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText ("[GetWin32OSFromRemoteSystem] Error contacting " + $MachineName)
		continue
	}
	
	#Obtain OS From Remote Machine and return the WMI class.
	#If error communicating, return the exeption error code instead of WMI class
	$Error.Clear()	
	$OS = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $MachineName
	
	if ($Error.Count -gt 0)
	{
		Return $Error[0].Exception.ErrorCode
	} 
	else 
	{
		return $OS
	}
}

trap [Exception] 
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

do
{
	do
	{
		#_#$RemoteServerCore = get-diaginput -id "BrowseServerCore"
		$RemoteServerCore = Read-Host 'please supply Remote-Server-Name: ' #_#
	} while (($RemoteServerCore[0] -eq 0) -or ($RemoteServerCore[0] -eq $null))

	$Error.Clear()

	#_#$RemoteServerCore = $RemoteServerCore[0].ToUpper()
	$RemoteServerCore = $RemoteServerCore.ToUpper() #_#

	Write-DiagProgress -Activity ($Strings.ID_EPSConnectingTo -replace("%MACHINE%", $RemoteServerCore)) -Status $Strings.ID_EPSConnectingToDesc

	$RemoteMachineOS = GetWin32OSFromRemoteSystem $RemoteServerCore
	
	if ($RemoteMachineOS -isnot [wmi])
	{
		if ($Error[0].Exception.ErrorCode -eq -2147023174) #The RPC server is unavailable. (Exception from HRESULT: 0x800706BA)
		{
			get-diaginput -id "ErrorContactingServerCore" -Parameter @{"Machine"=$RemoteServerCore; "Error"=$Strings.ID_EPSConnectingRCPError}
		} 
		else 
		{
			get-diaginput -id "ErrorContactingServerCore" -Parameter @{"Machine"=$RemoteServerCore; "Error"= $Error[0].Exception.Message}
		}
		
		$Error.Clear()
	}
	else
	{
		$Error.Clear()
		if ($RemoteMachineOS.BuildNumber -gt 7000)
		{
			$Error.Clear()
			
			#Now connect to machine to see if it is a Cluster
			$RemoteReg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $RemoteServerCore)
	
			if ($Error.Count -eq 0)
			{
				$RemoteNodesKey = $RemoteReg.OpenSubKey("Cluster\Nodes")
				
				if ($RemoteNodesKey.SubKeyCount -gt 0)
				{
					$ClusterName = $RemoteReg.OpenSubKey("Cluster", $false).GetValue("ClusterName").ToUpper()
					
					$Choices = @()
					
					foreach ($SubKey in $RemoteNodesKey.GetSubKeyNames())
					{
						$NodeMachineName = $RemoteReg.OpenSubKey("Cluster\Nodes\$SubKey", $false).GetValue("NodeName").ToUpper()
						
						if ($NodeMachineName -ne $RemoteServerCore) 
						{
							$ExtensionPoint = ""
						} else {
							#Set the machine indicated by customer the default
							$ExtensionPoint = "<Default/>"
						}

						$Choices += @{"Name"=$NodeMachineName;"Value"=$NodeMachineName;"Description"=$NodeMachineName;"ExtensionPoint"=$ExtensionPoint}
						
					}

					$TroubleshootingNodeNames = @()
					
					if ($Choices.Count -gt 0)
					{
						do
						{
							$TroubleshootingNodeNames = Get-DiagInput -Id SelectServerCoreClusterNodes -Parameter @{"Cluster"=$ClusterName; "Machine"=$RemoteServerCore} -Choice $Choices
							
						} while ($TroubleshootingNodeNames.Count -eq 0)

						if (($TroubleshootingNodeNames[0] -ne 0) -and ($TroubleshootingNodeNames.Count -ne 0))
						{
							if ($TroubleshootingNodeNames -contains "All")
							{
								foreach ($MachinName in $ClusterValues)
								{
									$MachineNames = $MachinName.Value
								}
							}
							else 
							{
								$MachineNames = $TroubleshootingNodeNames
							}
							
							Return $MachineNames

						}
					}
					else 
					{
						get-diaginput -id "ErrorContactingServerCore" -Parameter @{"Machine"=$NodeName; "Error"=$Strings.ID_EPSSelectNodesUnableObtainNames}
					}
				}
				else
				{
					#Machine is not a cluster node
					return $RemoteServerCore
				}
			}
			else
			{
				get-diaginput -id "ErrorContactingServerCore" -Parameter @{"Machine"=$RemoteServerCore; "Error"= $Error[0].Exception.Message}
			}
		}
		else
		{
			get-diaginput -id "ErrorContactingServerCore" -Parameter @{"Machine"=$RemoteServerCore; "Error"=$Strings.ID_EPSSelectNodesNotSupported.Replace("%Machine%",$NodeName).Replace("%OSName%",$RemoteMachineOS.Caption)}
		}
	}
} while ($true)