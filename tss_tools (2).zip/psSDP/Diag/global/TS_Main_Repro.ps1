﻿
# Load Common Library
#_#$debug = $false

. ./utils_cts.ps1
#_#. ./utils_Remote.ps1 #_#
#_#. ./TS_RemoteSetup.ps1 #_#

$FirstTimeExecution = FirstTimeExecution
if ($FirstTimeExecution) 
{
write-host "  FirstTimeExecution" -ForegroundColor cyan
	#Event Logs - System & Application logs
	$sectionDescription = "Event Logs (System and Application)"
	$EventLogNames = "System", "Application"
	#_#	Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

	# Auto Added Commands [AutoAdded]
	.\TS_AutoAddCommands_Repro.ps1

	EndDataCollection
	

} 
else
{	write-host " no FirstTimeExecution" -ForegroundColor cyan
	Collect-DiscoveryFiles
	#2nd execution. Delete the temporary flag file then exit
	EndDataCollection -DeleteFlagFile $True
	
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

