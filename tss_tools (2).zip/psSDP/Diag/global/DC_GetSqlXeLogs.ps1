﻿# This script has dependencies on utils_CTS and utils_DSD
#
param ( [Object[]] $instances, [switch]$CollectSqlDefaultDiagnosticXeLogs ,[switch]$CollectFailoverClusterDiagnosticXeLogs ,[switch]$CollectAlwaysOnDiagnosticXeLogs )  

# Certain properties of the SQL 2012 Failover Cluster and Always On XE logs can be customized.  
# The custom values are stored in registry values under key:
# HKLM:\Software\Microsoft\Microsoft SQL Server\<instance root>\MSSQLServer key
#
New-Variable LogFileRolloverCount		-Value "LogFileRolloverCount"   -Option ReadOnly
New-Variable LogMaxFileSizeINMBytes		-Value "LogMaxFileSizeINMBytes" -Option ReadOnly
New-Variable LogPath					-Value "LogPath"                -Option ReadOnly
New-Variable LogIsEnabled				-Value "LogIsEnabhled"          -Option ReadOnly


#
# Function : Get-XeDirectoryPathDefault
# -------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is used to find the path to the SQL Server errorlog for a given instance of SQL Server
# 
# Arguments:
#			$InstanceName
#			Function will find the default path to the SQL Server XE Health logs
# 
# Owner:
#			DanSha 
#
function Get-XeDirectoryPathDefault([string]$SqlInstance )
{
	$Error.Clear()           
	trap 
	{
		'[Get-XeDirectoryPathDefault] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error
	}

	return (Get-SqlServerLogPath -SqlInstance $SqlInstance)
}

#function CollectAndCompress-XeLogFiles ( [string]$XeLogDir, [bool] $IsClustered, [string]$instance, [string]$FileFilter )
#{     
#    trap 
#    {
#    	'[CollectAndCompress-XeLogFiles] : [ERROR] Trapped exception ...' | WriteTo-StdOut
#    	Report-Error 
#    }
#    
#    if ($FileFilter.Contains("SQLDIAG"))
#    {
#        $XeType = "Failover_Cluster_Diagnostics_health"
#    } 
#    elseif ($FileFilter.Contains("system_health"))
#    {
#        $XeType = "System_health"
#    }
#    elseif ($FileFilter.Contains("AlwaysOn"))
#    {
#        $XeType = "AlwaysOn_health"
#    }   
#    
#    if (Test-Path -Path $XeLogDir -Type "Container")
#    {
#        # Collect specified XE log files.  Have 90+ percent compression ratio so not worried about number and size
#        $XeLogfiles = get-childitem -Path (Join-Path $XeLogDir "*") -Include $FileFilter | foreach-object { Join-Path $_.DirectoryName $_.Name }
#        
#         if ($null -ne $XeLogfiles)
#         {
#            if (0 -lt $XeLogfiles.Count)
#    		{	
#				"[CollectAndCompress-XeLogFiles] : Found {0} {1} XE logs" -f $XeLogFiles.Count, $XeType | WriteTo-StdOut
#						
#    			# Compress and collect the XE files for this instance
#    			$ArchiveOut = "{0}_{1}_{2}_XeFiles.zip" -f $ComputerName, $instance, $XeType
#    			CompressCollectFiles -FilesToCollect $XeLogfiles -DestinationFileName $ArchiveOut -SectionDescription ("SQL Server {0} health files for instance: {1}" -f $XeType, $instance)
#    		}
#         }
#		 else
#		 {
#			"[CollectAndCompress-XeLogFiles] : Found 0 {1} XE logs" -f $XeType | WriteTo-StdOut
#		 }
#    }
#    else 
#	{
#		# Here is where we should do the check to see if this is a cluster and whether the drive is offline
#		"[CollectAndCompress-XeLogFiles] : Path to SQL XE logs: [{0}] for instance: {1} is invalid" -f $XeLogDir, $InstanceToCollect | WriteTo-StdOut
#			
#		# Check if drive that errorlogs are stored on is a cluster resource if the instance is clustered
#		if ($IsClustered)
#		{
#			$ParsedPath = $SqlErrorLogPath.Path.Split("\")
#			$ClusterDrive = $ParsedPath[0]
#			# Call function FindSqlDiskResource to see if the cluster resource is unavailable
#			#
#			if ($false -eq (FindSQLDiskResource($ClusterDrive)))
#			{
#				"[CollectAndCompress-XeLogFiles] : The cluster resource: [{0}] that the XE log files for instance: {1} are stored on is not available at this time" -f $ClusterDrive, $InstanceToCollect | WriteTo-StdOut
#			}
#		}
#	}
#    
#}

# Checks to see if customer set a custom diagnostics log location using ALTER SERVER CONFIGURATION DIAGNOSTICS LOG
function Get-XeDirectoryPathCustom ([string] $InstanceName)
{   
    trap 
    {
    	"[Get-XeDirectoryPathCustom] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
    }  

    if ($null -ne $InstanceName)
    {
    	$SqlRootKey =  Get-SqlInstanceRootKey $InstanceName   
        
        # First make sure we have a valid "root" key for this instance
        if (Test-Path -Path $SqlRootKey)
        {
            if ($null -ne $SqlRootKey)
            {
                 if ($true -eq (Test-RegistryValueExists (Join-Path -Path $SqlRootKey -ChildPath "MSSQLSERVER") $LogPath))
                 {
                    #Customer has modified the default XE log path with the ALTER SERVER 
                    [System.IO.Path]::GetDirectoryName((Get-ItemProperty (Join-Path $SqlRootKey "MSSQLSERVER")).$LogPath)
                 }
             }
         }
    } # if ($null -eq $InstanceName)
    else
    {
        '[Get-XeDirectoryPathCustom] : [ERROR] Required parameter -InstanceName not specified' | WriteTo-StdOut
    }
}


# This function retrieves the directory path for the Failover Cluster XE logs and Always On 
function Get-XeDirectoryPath ([string] $InstanceName)
{
    trap 
    {
    	"[Get-XeDirectoryPath] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
    
	# Validate required parameter was supplied
	if ($null -ne $InstanceName)
	{
	    # The XE log path can be customized using the ALTER SERVER DIAGNOSTICS command for FCI and AlwaysOn (but not default system health)
	    # so try to retrieve custom path first. If found, we will use that instead of the default path.
	    $XeLogPath = Get-XeDirectoryPathCustom $InstanceName
	    
	    if ($null -eq $XeLogPath )
	    {
	        # Custom path not set; retrieve default XE log path
	        $XeLogPath = Get-XeDirectoryPathDefault $InstanceName
	    }
    }
	else
	{
		'[Get-XeDirectoryPath] : [ERROR] Required parameter -InstanceName was not supplied' | WriteTo-StdOut
	}
    return $XeLogPath
}

function Collect-SqlXeGeneralHealthSessionLogs ([string]$InstanceName, [bool]$IsClustered)
{
    $Error.Clear()           
    trap 
    {
    	"[Collect-SqlXeHealthSessionLogs] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error 
    }
    
	if ($null -ne $InstanceName)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            # Post progress message to dialog visible to user
        	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthalLogDesc + ": " + $InstanceName)

            # SQL Health sessions are always in default log folder. Not configurable
            $XeHealthSessionLogDir = Get-XeDirectoryPathDefault $InstanceName 
            
            if ($null -ne $XeHealthSessionLogDir)
            {
                # Valid path?
                if ($true -eq (Test-Path -Path $XeHealthSessionLogDir))
                {
                    $FciFiles = @()
    				$FciFiles = Copy-FileSql -SourcePath $XeHealthSessionLogDir `
                             -FileFilters @('system_health*.XEL') `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_SYSTEM_HEALTH_XELOGS  `
                             -InstanceName $InstanceName `
    						 -SectionDescription ("'General System Health logs for instance {0}" -f $InstanceName) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_system_health_XeLogs.zip" -f $ComputerName, $InstanceName)
                }
                else
                {
                    # Does the log path reference a cluster disk that is offline from this node at this time?
                    if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceName -PathToTest $XeHealthSessionLogDir))
        	        {
        	            "[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] No Sql General System Health logs will be collected. Path to General Health XE logs: [{0}] for instance: [{1}] is invalid" -f $XeHealthSessionLogDir, $InstanceName | WriteTo-StdOut
        	        } 
                }
            }
            else
            {
                '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Get-XeDirectoryPathDefault returned a null path to Sql Server general system health Xe logs' | WriteTo-StdOut
            }
        
        } #if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        else
        {
            '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Required parameter -IsClustered was not specified or contains an incorrect value' | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceName)
    else
    {
        '[Collect-SqlXeGeneralHealthSessionLogs] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut
    }
	
}

#
# Function : Collect-SqlFailoverClusterDiagnosticXeLogs
# -----------------------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function enumerates the Failover Cluster Diagnostic Xel files and calls the CollectAndCompress-XeLogFiles
#           to collect the log files from the customer machine.
#           Note that there can be quite a large number of these files present on a server at any given time.
#           We do not limit the number or age of the files we collect because they compress at better than 90% compression ratio
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
function Collect-SqlFailoverClusterDiagnosticXeLogs ( [string]$InstanceName, [bool]$IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[Collect-SqlXeFailoverClusterLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }
    
	# Post progress message to dialog visible to user
	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeFailoverClusterlHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeFailoverClusterlHealthLogsDesc + ": " + $InstanceName)

    if ($null -ne $InstanceName) 
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            $XeFailoverClusterLogPath = Get-XeDirectoryPath $InstanceName 

        	if ($null -ne $XeFailoverClusterLogPath)
            {
                if ($true -eq (Test-Path -Path $XeFailoverClusterLogPath))
            	{
                    # FCI XEL Filename Format: <COMPUTER_NAME>_<INSTANCE_NAME>_SQLDIAG_*  
                    # Actual Example:          215126NEWNODE2_MSSQLSERVER_SQLDIAG_0_129719944456780000.xel
                    # Search Mask:             *<INSTANCE_NAME>_SQLDIAG*.XEL
                    #
                    # These files are created on a shared drive (cluster resource) and the file name includes the name of the node where the file was created.  
                    # As such, we cannot include the COMPUTER_NAME in the -FileFilter argument as this part of the file name will be determined by 
                    # the NETBIOS computer name of the node SQL Server was executing on at the time the file was created
                   	                    # Enumerate and then copy the files
                                                
    				$FciFiles = @()
    				$FciFiles = Copy-FileSql -SourcePath $XeFailoverClusterLogPath `
                             -FileFilters @("*_{0}_SQLDIAG*.XEL" -f $InstanceName) `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_FAILOVER_CLUSTER_XELOGS `
                             -InstanceName $InstanceName `
    						 -SectionDescription ("'Failover Cluster Health logs for instance {0}" -f $InstanceName) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_FailoverCluster_health_XeLogs.zip" -f $ComputerName, $InstanceName)
                             
                   # Report outcome of collection to stdout.log
                   if (($null -ne $FciFiles) -and (0 -lt $FciFiles.Count))
                   {
                        "[Collect-SqlXeFailoverClusterHealthLogs] : [INFO] [{0}] Sql Failover Cluster diagnostic logs collected for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
                   }
                   else
                   {
                        "[Collect-SqlXeFailoverClusterHealthLogs] : [INFO] No Sql Failover Cluster diagnostic logs collected for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
                   }
                   
            	} #if ($true -eq (Test-Path -Path $XeFailoverClusterLogPath))
                else
                {
        			if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceName -PathToTest $XeFailoverClusterLogPath))
        	        {
        	            "[Collect-SqlXeFailoverClusterHealthLogs] : [ERROR] No SQL Sql Failover Cluster diagnostic logs will be collected. Path to failover cluster diagnositcs logs: [{0}] for instance: {1} is invalid" -f $XeFailoverClusterLogPath, $InstanceName | WriteTo-StdOut
        	        }      
                }
            
            } # if ($null -ne $XeFailoverClusterLogPath)
            else
            {
                "[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Get-XeDirectoryPath returned a null log path for instance: [{0}]" -f $InstanceName | WriteTo-StdOut
            }
            
            
        }  # if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        else
        {
            '[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Required parameter -IsClustered was not specified' | WriteTo-StdOut
        }

    } # if ($null -ne $InstanceName)
    else
    {
        '[Collect-SqlFailoverClusterDiagnosticXeLogs] : [ERROR] Required parameter -InstanceName was not specified' | WriteTo-StdOut
    }
}

#
# Function : Collect-SqlAlwaysOnDiagnosticXeLogs
# ----------------------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function drives logic to collect the AlwaysOn Diagnostic logs
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
# Sample AlwaysOn file name:
#           AlwaysOn_health_0_129736303650760000.xel
#
function Collect-SqlAlwaysOnDiagnosticXeLogs( [string] $Instance, [bool] $IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[Collect-SqlAlwaysOnDiagnosticXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }  
    
    If ($null -ne $Instance)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
        	# Post progress message to dialog visible to user
        	Write-DiagProgress -Activity $xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthLogs -Status ($xeHealthLogsCollectorStrings.ID_SQL_CollectSqlXeGeneralHealthalLogDesc + ": " + $Instance)
            
        	$XeAlwaysOnLogPath = Get-XeDirectoryPath -InstanceName $Instance 
            
        	if ($null -ne $XeAlwaysOnLogPath)
            {
                if ($true -eq (Test-Path -Path $XeAlwaysOnLogPath))
            	{
                                
                    # Enumerate and then copy the files
    				$Files = @()
    				$Files = Copy-FileSql -SourcePath $XeAlwaysOnLogPath `
                             -FileFilters @('AlwaysOn_health*.XEL') `
                             -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ALWAYSON_XELOGS `
                             -InstanceName $Instance `
    						 -SectionDescription ("'AlwaysOn Health logs for instance {0}" -f $Instance) `
                             -CompressCollectedFiles `
                             -ZipArchiveName ("{0}_{1}_AlwaysOn_health_XeLogs.zip" -f $ComputerName, $Instance)
                    
                    # Report number of logs enumerated and copied
                    if (($null -ne $Files) -and (0 -lt $Files.Count))
                    {
                        "[Collect-SqlXeAlwaysOnHealthLogs] : [INFO] Collected [{0}] AlwaysOn diagnostic logs for instance: [{1}]" -f $Files.Count, $Instance | WriteTo-StdOut
                    }
                    else
                    {
                        "[Collect-SqlXeAlwaysOnHealthLogs] : [INFO] No AlwaysOn diagnostic logs were collected for instance: [{0}]" -f $Instance | WriteTo-StdOut
                    }
                    
                }
                else
                {
                    # Does the log path reference a cluster disk that is offline from this node at this time?
                    if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $Instance -PathToTest $XeAlwaysOnLogPath))
        	        {
        	            "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] No SQL Server AlwaysOn diagnostic logs will be collected. Path to AlwaysOn Diagnostic logs: [{0}] for instance: [{1}] is invalid" -f $XeAlwaysOnLogPath, $Instance | WriteTo-StdOut
        	        }
                      
                }
                
            } # if ($null -ne $XeAlwaysOnLogPath)
            else
            {
                "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Get-XeDirectoryPath returned a null path to the AlwaysOn Xe logs for instance: [{0}]" -f $Instance | WriteTo-StdOut
            }
            
        } # if ($null -ne $IsClustered)
        else
        {
            "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Required parameter -IsClustered was not specified" | WriteTo-StdOut
        }
        
    } # If ($null -ne $Instance)
    else
    {
        "[Collect-SqlXeAlwaysOnHealthLogs] : [ERROR] Required parameter -Instance was not specified" | WriteTo-StdOut
    }
}

#
# Function : Collect-SqlXeLogs
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that drives Xe log collection based on switch parameters that the script is called with
# 
# Arguments:
#			$InstanceName
#			Instance that Xe logs will be collected for
#           $IsClustered
#           Is the instance clustered?  Only really needed to detect if the drive we need to collect the logs from is offline from the node we are collecting on
# 
# Owner:
#			DanSha 
#
function Collect-SqlXeLogs ( [string] $InstanceName, [bool] $IsClustered )
{
    $Error.Clear()           
    trap 
    {
    	'[DC-GetSqlXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
    	Report-Error
    }    
    
    if ($null -ne $InstanceName)
    {
        if (($true -eq $IsClustered) -or ($false -eq $IsClustered))
        {
            # Collect Sql Server General/Default Diagnostic Session Xe Log files?    
            if ($true -eq $CollectSqlDefaultDiagnosticXeLogs)
            {
                # Collect the Health Session XE files that are on by default
                Collect-SqlXeGeneralHealthSessionLogs -InstanceName $InstanceName -IsClustered $IsClustered
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql Default Health Session Xe log collection bypassed. $CollectSqlHealthXeLogs: {0}' -f $CollectSqlDefaultDiagnosticXeLogs | WriteTo-StdOut
            }
            
            # Collect failover cluster diagnostic Xe log files?
            if ($true -eq $CollectFailoverClusterDiagnosticXeLogs)
            {
                # Collect the SQL Server failover cluster diagnostic log files
                Collect-SqlFailoverClusterDiagnosticXeLogs -InstanceName $InstanceName -IsClustered $IsClustered 
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql Failover Cluster Diagnostic Xe log collection bypassed. $CollectFailoverClusterDiagnosticXeLogs: {0}' -f $CollectFailoverClusterDiagnosticXeLogs | WriteTo-StdOut
            }
            
            # Collect Always On Diagnostic Xe logs?
            if ($true -eq $CollectAlwaysOnDiagnosticXeLogs)
            {
                # Collect the Always On diagnostic log files
                Collect-SqlAlwaysOnDiagnosticXeLogs -Instance $InstanceName -IsClustered $IsClustered 
            }
            else
            {
                # Echo collection option to stdout.log
                '[Collect-SqlXeLogs] : [INFO] Sql AlwaysOn Diagnostic Xe log collection bypassed. $CollectAlwaysOnHealthXeLogs: {0}' -f $CollectAlwaysOnHealthXeLogs | WriteTo-StdOut
            }
                
        } # if ($null =ne $IsClustered)
        else
        {
            '[Collect-SqlXeLogs] : [ERROR] Required parameter -IsClustered was not secified' | WriteTo-StdOut
        }
        
    } # if ($null -eq $InstanceName)
    else
    {
          '[Collect-SqlXeLogs] : [ERROR] Required parameter -InstanceName was not secified' | WriteTo-StdOut
    }
}
	
$Error.Clear()           
trap 
{
   	'[DC_GetSqlXeLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
   	Report-Error
}  

Import-LocalizedData -BindingVariable xeHealthLogsCollectorStrings

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
    
    if (($null -ne $instances) -and (0 -lt $instances.count))
    {
        foreach ($instance in $instances)
        {
			# Only try to collect these logs on SQL Sever 2012 or later
            if ($global:SQL:SQL_VERSION_MAJOR_SQL2012 -le $instance.SqlVersionMajor)
			{
				if ('DEFAULT' -eq $instance.InstanceName.ToUpper() ) {$instance.InstanceName = 'MSSQLSERVER'}
                
				Collect-SqlXeLogs -InstanceName $instance.InstanceName -IsClustered $instance.IsClustered 
			}
			else
			{
				"[DC-GetSqlXeLogs] : No SQL Server system health logs were collected for instance {0}" -f $instance.InstanceName | WriteTo-StdOut
				"[DC-GetSqlXeLogs] : SQL instance must be SQL Server 2012 or later.  Major version for instance {0} is {1}" -f $instance.InstanceName, $instance.SqlVersionMajor | WriteTo-StdOut
			}
            
        } # foreach ($instance in $instances)
        
    } # if (($null -ne $instances) -and (0 -lt $instances.count))
    else
    {
        'DC-GetSqlXeLogs] : [ERROR] Enumerate-SqlInstances returned a null instance array' | WriteTo-StdOut
    }
}
else
{
    "[DC-GetSqlXeLogs] : [INFO] SQL Server is not installed on computer: [{0}]" -f $env:ComputerName | WriteTo-StdOut
}
# SIG # Begin signature block
# MIIa9AYJKoZIhvcNAQcCoIIa5TCCGuECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUQvvkgs2K7Void5UgwsrEVRdD
# 6qSgghWCMIIEwzCCA6ugAwIBAgITMwAAADPlJ4ajDkoqgAAAAAAAMzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTMwMzI3MjAwODIz
# WhcNMTQwNjI3MjAwODIzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyt7KGQ8fllaC
# X9hCMtQIbbadwMLtfDirWDOta4FQuIghCl2vly2QWsfDLrJM1GN0WP3fxYlU0AvM
# /ZyEEXmsoyEibTPgrt4lQEWSTg1jCCuLN91PB2rcKs8QWo9XXZ09+hdjAsZwPrsi
# 7Vux9zK65HG8ef/4y+lXP3R75vJ9fFdYL6zSDqjZiNlAHzoiQeIJJgKgzOUlzoxn
# g99G+IVNw9pmHsdzfju0dhempaCgdFWo5WAYQWI4x2VGqwQWZlbq+abLQs9dVGQv
# gfjPOAAPEGvhgy6NPkjsSVZK7Jpp9MsPEPsHNEpibAGNbscghMpc0WOZHo5d7A+l
# Fkiqa94hLwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFABYGz7txfEGk74xPTa0rAtd
# MvCBMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAL/44wD6u9+OLm5fJ87UoOk+iM41AO4alm16uBviAP0b1Fq
# lTp1hegc3AfFTp0bqM4kRxQkTzV3sZy8J3uPXU/8BouXl/kpm/dAHVKBjnZIA37y
# mxe3rtlbIpFjOzJfNfvGkTzM7w6ZgD4GkTgTegxMvjPbv+2tQcZ8GyR8E9wK/EuK
# IAUdCYmROQdOIU7ebHxwu6vxII74mHhg3IuUz2W+lpAPoJyE7Vy1fEGgYS29Q2dl
# GiqC1KeKWfcy46PnxY2yIruSKNiwjFOPaEdHodgBsPFhFcQXoS3jOmxPb6897t4p
# sETLw5JnugDOD44R79ECgjFJlJidUUh4rR3WQLYwggTsMIID1KADAgECAhMzAAAA
# sBGvCovQO5/dAAEAAACwMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTEzMDEyNDIyMzMzOVoXDTE0MDQyNDIyMzMzOVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOivXKIgDfgofLwFe3+t7ut2rChTPzrbQH2zjjPmVz+l
# URU0VKXPtIupP6g34S1Q7TUWTu9NetsTdoiwLPBZXKnr4dcpdeQbhSeb8/gtnkE2
# KwtA+747urlcdZMWUkvKM8U3sPPrfqj1QRVcCGUdITfwLLoiCxCxEJ13IoWEfE+5
# G5Cw9aP+i/QMmk6g9ckKIeKq4wE2R/0vgmqBA/WpNdyUV537S9QOgts4jxL+49Z6
# dIhk4WLEJS4qrp0YHw4etsKvJLQOULzeHJNcSaZ5tbbbzvlweygBhLgqKc+/qQUF
# 4eAPcU39rVwjgynrx8VKyOgnhNN+xkMLlQAFsU9lccUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRZcaZaM03amAeA/4Qevof5cjJB
# 8jBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# NGZhZjBiNzEtYWQzNy00YWEzLWE2NzEtNzZiYzA1MjM0NGFkMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAx124qElczgdWdxuv5OtRETQie
# 7l7falu3ec8CnLx2aJ6QoZwLw3+ijPFNupU5+w3g4Zv0XSQPG42IFTp8263Os8ls
# ujksRX0kEVQmMA0N/0fqAwfl5GZdLHudHakQ+hywdPJPaWueqSSE2u2WoN9zpO9q
# GqxLYp7xfMAUf0jNTbJE+fA8k21C2Oh85hegm2hoCSj5ApfvEQO6Z1Ktwemzc6bS
# Y81K4j7k8079/6HguwITO10g3lU/o66QQDE4dSheBKlGbeb1enlAvR/N6EXVruJd
# PvV1x+ZmY2DM1ZqEh40kMPfvNNBjHbFCZ0oOS786Du+2lTqnOOQlkgimiGaCMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBNwwggTY
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAsBGvCovQO5/d
# AAEAAACwMAkGBSsOAwIaBQCggfUwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFMZq
# BOUVTacS2/19kf3c4vAfcPLnMIGUBgorBgEEAYI3AgEMMYGFMIGCoGiAZgBEAEkA
# QQBHAF8AQwBUAFMAXwBHAGUAbgBlAHIAYQBsAF8AUgBlAHAAbwByAHQAcwBfAGcA
# bABvAGIAYQBsAF8ARABDAF8ARwBlAHQAUwBxAGwAWABlAEwAbwBnAHMALgBwAHMA
# MaEWgBRodHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQA2Hs2l
# 6Ao56kXI6VHhaQkNrF0PpWey0bMaMIyS4jkIrL0G60G8VpL1CQLoBxJiTQ0edJge
# k0ZK0qf+ajDNQdZMST9JbYBhTNKCkGHiIfDeYCmiZxlPE5ZjCkuJBg3SVzZG1aH5
# 52GaPJ3Z6zHHMOjKIek9mMO0f4Is09gGBSRYSfn8DGHH7QoZxCCGknbKu8mrfd6A
# 6sHdvm2wRdc3rLBfaVd3Gy7xdZnY/5swqgyjM38/pLLEiiLd7CWpBka3QUov2BMl
# qgmQtc6nAvdF/OA9aeHqv8+WpTwTexJflXoV4zmjxhXy4JQNando4ArR1f1GVsFA
# lVdLPViFt3FwPq04oYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQQITMwAAADPlJ4ajDkoqgAAAAAAAMzAJBgUr
# DgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUx
# DxcNMTQwMjI0MTczNzU3WjAjBgkqhkiG9w0BCQQxFgQUVMYnnQ9dMmjfYWp7+Qx6
# xBD/kjkwDQYJKoZIhvcNAQEFBQAEggEABrYgINEdnf8FIbyrZDlFp61aRzPj7H7t
# /Nvlaa5c88tinZs/hnPWOF/ZBHvX4oRNYBYl/j0Nt6c9avf3dca7ekvxwUAanI9w
# QtaZCw9Xv6by/3zmRqtxBogBdIX6GmQNGbuGIflzSl6UKll5FevjniQJIE7bgBHb
# IKZZ8gL7Ew8Tib782GdZcCScslHuj0ZEaOANQfo2PbDiNICE5El/bKXfer0hlFJa
# Wx/G99Vilejp42px6xDpmBSF47/liwapvDMyCV2M1vLlOAoWAcy+BYzbUTsNyi9U
# NrT5yhrrOOwJYxGillxxJzRsroXYCyr1SySieDEJAiu14uOOcwsaUA==
# SIG # End signature block
