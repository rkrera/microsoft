﻿#************************************************
# DC_BasicClusterInfo.ps1
# Version 2.0.3
# Date: 03-28-2010
# Author: Andre Teixeira - andret@microsoft.com
# Description: This script writes to the report basic information regarding 
#              the cluster (Cluster Info, Nodes and Groups)
#************************************************


#Troubleshooter:

PARAM([switch] $IncludeCoreGroups)

# 2019-03-17 WalterE added Trap #_#
Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
	
$ClusterSvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\ClusSvc"

if (Test-Path $ClusterSvcKey)
{
	Import-LocalizedData -BindingVariable ClusterBasicInfo 
	Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status $ClusterBasicInfo.ID_ClusterInfoObtaining

	$StartupType = (get-itemproperty -Path $ClusterSvcKey -Name "Start").Start
	if (($StartupType -eq 2) -or ($StartupType -eq 3)) 
	{  # Auto or Manual
		if ($StartupType -eq 2) {$StartupTypeDisplay = "Auto"}
		if ($StartupType -eq 3) {$StartupTypeDisplay = "Manual"}
		$ClusterSvc = Get-Service -Name ClusSvc
		if ($ClusterSvc.Status.Value__ -ne 4) 
		{ #Cluster Service is not running
			Update-DiagRootCause -id "RC_ClusterSvcDown" -Detected $true 
			$InformationCollected = @{"Service State"=$ClusterSvc.Status; "Startup Type"=$StartupTypeDisplay}
			Write-GenericMessage -RootCauseID "RC_ClusterSvcDown" -Component "FailoverCluster" -InformationCollected $InformationCollected -Verbosity "Error" -PublicContentURL "http://blogs.technet.com/b/askcore/archive/2010/06/08/windows-server-2008-and-2008r2-failover-cluster-startup-switches.aspx" -SupportTopicsID 8001 -MessageVersion 2 -Visibility 4
		}
		else 
		{
			Update-DiagRootCause -Id "RC_ClusterSvcDown" -Detected $false
			$ClusterKey="HKLM:\Cluster"
			
			#   Win2K8 R2
			if ((Test-Path $ClusterKey) -and ($OSVersion.Build -gt 7600))
			{
				Import-Module FailoverClusters
				
				$Cluster = Get-Cluster
				
				$Cluster_Summary = new-object PSObject
				
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterName -value $cluster.Name
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterDomain -value $cluster.Domain
				add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterCSV -value $cluster.EnableSharedVolumes
				
				if ($cluster.EnableSharedVolumes -eq "Enabled") 
				{
					add-member -inputobject $Cluster_Summary -membertype noteproperty -name $ClusterBasicInfo.ID_ClusterCSVRoot -value $cluster.SharedVolumesRoot
				}
				
				$Cluster_Summary | convertto-xml | update-diagreport -id 02_ClusterSummary -name $ClusterBasicInfo.ID_ClusterInfo -verbosity informational

				$ClusterQuorum_Summary = new-object PSObject
				$ClusterQuorum = Get-ClusterQuorum

				add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "Quorum Type" -value $ClusterQuorum.QuorumType
				if ($ClusterQuorum.QuorumResource -ne $null) 
				{
					add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "Quorum Resource" -value $ClusterQuorum.QuorumResource.Name
					
						switch ($ClusterQuorum.QuorumResource.State.value__) {
							2 {$Color = "Green"} #ClusterResourceOnline 
							3 {$Color = "Black"} #ClusterResourceOffline
							4 {$Color = "Red"}   #ClusterResourceFailed
							default { $Color = "Orange" } #Other state
						}

						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterQuorum.QuorumResource.State
						$ResourceStateDisplay = $State + " - Owner: " + $ClusterQuorum.QuorumResource.OwnerNode
						
						add-member -inputobject $ClusterQuorum_Summary -membertype noteproperty -name "State" -value $ResourceStateDisplay
				}

				$ClusterQuorum_Summary | convertto-xml2 | update-diagreport -id 03_ClusterQuorumSummary -name "Quorum Information" -verbosity informational
				
				$ClusterNodes_Summary = new-object PSObject
				$ClusterNodesNotUp_Summary = new-object PSObject
				
				Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Nodes"
				
				$Error.Clear()
				
				$ClusterNodes = Get-ClusterNode
				
				if ($Error.Count -ne 0) 
				{
					$errorMessage = $Error[0].Exception.Message
					$errorCode = "0x{0:X}" -f $Error[0].Exception.ErrorCode
					$ServiceState = $ClusterSvc.Status
					Update-DiagRootCause -id "RC_ClusterInfoErr" -Detected 
					$InformationCollected = @{"Error Message"=$errorMessage; "Error Code"=$errorCode; "Service State" = $ServiceState}
					Write-GenericMessage -RootCauseID "RC_ClusterInfoErr" -InformationCollected $InformationCollected -Verbosity "Warning" -Component "FailoverCluster"  -SupportTopicsID 8001 -MessageVersion 2 -Visibility 3
				}
				
				if ($ClusterNodes -ne $Null) 
				{
					$ReportNodeNotUpNames=""
					foreach ($ClusterNode in $ClusterNodes) 
					{
						switch ($ClusterNode.State.value__) 
						{
							0 {$Color = "Green"} # Up
							1 {$Color = "Red"}   #Down
							default { $Color = "Orange" } 
						}

						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterNode.State
						$NodeName = $ClusterNode.NodeName
						if ($NodeName -eq "$ComputerName") {$NodeName += "*"}
						add-member -inputobject $ClusterNodes_Summary -membertype noteproperty -name $NodeName -value $State
						if ($ClusterNode.State.value__ -ne 0 ) 
						{ 
							if ($ReportNodeNotUpNames -ne "") 
							{
								$ReportNodeNotUpNames += ", "
							}
							$ReportNodeNotUpNames += $ClusterNode.NodeName + "/ " + $ClusterNode.State
							add-member -inputobject $ClusterNodesNotUp_Summary -membertype noteproperty -name $NodeName -value ($ClusterNode.State)
						}
					}
		
					if ($ReportNodeNotUpNames -ne "") 
					{
						$XMLFile = "..\ClusterNodesDown.XML"
						#$XMLObj = $ClusterNodesNotUp_Summary | ConvertTo-Xml2 
						#$XMLObj.Save($XMLFile)
						Update-DiagRootCause -id "RC_ClusterNodeDown" -Detected $true #-Parameter @{"NotUpNodesXML"=$XMLFile}
						#$InformationCollected = @{"Cluster Node(s)/ State"= $ReportNodeNotUpNames}
						Write-GenericMessage -RootCauseID "RC_ClusterNodeDown" -InformationCollected $ClusterNodesNotUp_Summary -SupportTopicsID 8001 -MessageVersion 2 -Visibility 3
					}
					else
					{
						Update-DiagRootCause -Id "RC_ClusterNodeDown" -Detected $false
					}
					
					$ClusterNodes_Summary | ConvertTo-Xml2 | update-diagreport -id 04_ClusterNodes -name "Cluster Nodes" -verbosity informational
					
					Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Groups"
					
					$ClusterGroups_Summary = new-object PSObject
					$ClusterGroupNotOnline_Summary = new-object PSObject
					
					if ($IncludeCoreGroups.IsPresent) {
						$ClusterGroups = Get-ClusterGroup
					} else {
						$ClusterGroups = Get-ClusterGroup | Where-Object {$_.IsCoreGroup -eq $false}
					}
					
					if ($ClusterGroups -ne $null)
					{
						$GroupNamesNotOnline = ""
						foreach ($ClusterGroup in $ClusterGroups) {
							switch ($ClusterGroup.State.value__) {
								0 {$Color = "Green"} #Online
								1 {$Color = "Black"}   #ClusterGroupOffline
								2 {$Color = "Red"} #ClusterGroupFailed
								3 {$Color = "Orange"} #ClusterGroupPartialOnline
								4 {$Color = "Yellow"} #ClusterGroupPending
								default { $Color = "Orange" } #Pending
							}

							$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterGroup.State
							$GroupStateDisplay = $State + " - Owner: " + $ClusterGroup.OwnerNode
							if (($IncludeCoreGroups.IsPresent) -and ($ClusterGroup.IsCoreGroup)) {
								$ClusterGroupDisplay = $ClusterGroup.Name + " (Core Group)"
							} else {
								$ClusterGroupDisplay = $ClusterGroup.Name
							}
							add-member -inputobject $ClusterGroups_Summary -membertype noteproperty -name $ClusterGroupDisplay -value $GroupStateDisplay
							
							if (($ClusterGroup.State.value__ -eq 1) -or ($ClusterGroup.State.value__ -eq 2)) 
							{ 
								if ($GroupNamesNotOnline -ne "") 
								{
									$GroupNamesNotOnline += ", "
								}
								$GroupNamesNotOnline += $ClusterGroup.Name + "/ " + $ClusterGroup.State
								add-member -inputobject $ClusterGroupNotOnline_Summary -membertype noteproperty -name $ClusterGroup.Name -value $GroupStateDisplay 
							}
						}

						if ($GroupNamesNotOnline -ne "") 
						{
							$XMLFileName = "..\ClusterGroupsProblem.XML"
							#$XMLObj = $ClusterGroupNotOnline_Summary | ConvertTo-Xml2 
							#$XMLObj.Save($XMLFileName)
							Update-DiagRootCause -id "RC_ClusterGroupDown" -Detected $true #-Parameter @{"XMLFilename"=$XMLFileName}
							$InformationCollected = @{"Cluster Group(s)" = $ClusterGroupNotOnline_Summary}
							Write-GenericMessage -RootCauseID "RC_ClusterGroupDown" -InformationCollected $InformationCollected -Verbosity "Warning" -Component "FailoverCluster" -PublicContentURL "http://technet.microsoft.com/en-us/library/cc757139(WS.10).aspx"
						}
						else
						{
							Update-DiagRootCause -id "RC_ClusterGroupDown" -Detected $false
						}

						$ClusterGroups_Summary | ConvertTo-Xml2 | update-diagreport -id 05_ClusterGroup -name "Cluster Groups" -verbosity informational
						
						if ($clusterGroups.Length -le 50)
						{
							foreach ($ClusterGroup in $ClusterGroups) {
								$ClusterGroup_Summary = new-object PSObject
								$GroupName = $ClusterGroup.Name
								Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Group $GroupName - Querying resources"
								foreach ($ClusterResourceType in get-clusterResource | Where-Object {$_.OwnerGroup.Name -eq $ClusterGroup.Name} | Select-Object ResourceType -Unique) {
									$ResourceTypeDisplayName = $ClusterResourceType.ResourceType.DisplayName
									Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Group $GroupName - Querying $ResourceTypeDisplayName resources"
									$ResourceLine = ""
									foreach ($ClusterResource in get-clusterResource | Where-Object {($_.ResourceType.Name -eq $ClusterResourceType.ResourceType.Name) -and ($_.OwnerGroup.Name -eq $ClusterGroup.Name)}){
										switch ($ClusterResource.State.value__) {
											2 {$Color = "Green"} #Online
											3 {$Color = "Black"} #Offline
											4 {$Color = "Red"}   #ClusterResourceFailed
											default { $Color = "Orange" } #Pending or other state
										}
										$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $ClusterResource.State
										if ($ResourceLine -ne "") { $ResourceLine += "<br/>" }
										$ResourceLine += $State + " - " + $ClusterResource.Name
									}			
									add-member -inputobject $ClusterGroup_Summary -membertype noteproperty -name $ResourceTypeDisplayName -value $ResourceLine
								}
								$strID = "05a_" + $GroupName + "_ClusterGroup"
								$ClusterGroup_Summary | ConvertTo-Xml2 | update-diagreport -id $strID -name "Cluster Group $GroupName" -verbosity informational
							}	
						}
						else
						{
							$ClusterGroup_Summary = new-object PSObject
							$ClusterGroup_Summary | ConvertTo-Xml2 | update-diagreport -id "05a" -name "A large number of cluster groups were detected on this system.  Detailed cluster group information is not available in Resultreport.xml" -verbosity informational
						}
						Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status $ClusterBasicInfo.ID_ClusterInfoObtaining
						
						
						
					}
				}
				
				
				$ClusterNetWorks = get-clusternetwork
				if($ClusterNetWorks -ne $null)
				{
					foreach($Psnetwork in $ClusterNetWorks)
					{
					    $PSClusterNetWork = New-Object PSObject
						$AutoMetric = ""
						$RoleDescription = ""
						$IPv6Addresses = ""
						$State = ""
						$Ipv4Addresses = ""
						if($Psnetwork.IPv6Addresses.Count -eq 0)
						{
							$IPv6Addresses = "None/0"
						}
						else
						{
							for($c =0 ;$c -lt $Psnetwork.IPv6Addresses.Count; $c++ )
							{
	
								if($c -eq $Psnetwork.IPv6Addresses.Count-1)
								{
									$IPv6Addresses += $Psnetwork.IPv6Addresses[$c] + " / " + $Psnetwork.Ipv6PrefixLengths[$c]
								}
								else
								{
									$IPv6Addresses += $Psnetwork.IPv6Addresses[$c] + " / " + $Psnetwork.Ipv6PrefixLengths[$c] +"<br/>"
								}
							}
						}
						
						if($Psnetwork.Ipv4Addresses.Count -eq 0)
						{
							$Ipv4Addresses = "None / None"
						}
						else
						{
							for($i =0 ;$i -lt $Psnetwork.Ipv4Addresses.Count; $i++ )
							{
	
								if($i -eq $Psnetwork.Ipv4Addresses.Count-1)
								{
									$Ipv4Addresses += $Psnetwork.Ipv4Addresses[$i] + " / " +$Psnetwork.AddressMask[$i]
								}
								else
								{
									$Ipv4Addresses += $Psnetwork.Ipv4Addresses[$i] + " / " +$Psnetwork.AddressMask[$i] +"<br/>"
								}
							}
						}
						
						if($Psnetwork.AutoMetric)
						{
							$AutoMetric = " [AutoMetric]"
						}
						switch ($Psnetwork.Role) 
						{
								0 {$RoleDescription = " (Do not allow cluster network communications on this network)"}
								1 {$RoleDescription = " (Allow cluster network communications on this network"}
								3 {$RoleDescription = " (Allow clients to connect through this network)"}
						   default{$RoleDescription = ' (Unknown)' }
						}

						$color = $null
						switch ($Psnetwork.State.value__) {
										1 {$Color = "Black"} #down
										2 {$Color = "Red"} #partitioned 
										3 {$Color = "Green"} #up
										default { $Color = "Orange" } #unavailable  or unknow
									}
						$State = "<font face=`"Webdings`" color=`"$Color`">n</font> " + $Psnetwork.State
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "State" -Value $State
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "IPv6 Addresses" -Value $IPv6Addresses
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "IPv4 Addresses" -Value $Ipv4Addresses
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "Metric" -Value ($Psnetwork.Metric.ToString() + $AutoMetric)
						Add-member -InputObject $PSClusterNetWork -Membertype Noteproperty -Name "Role" -Value ($Psnetwork.Role.ToString() + $RoleDescription)
	
						$PsClusterNetworkInfo = Convert-PSObjectToHTMLTable -PSObject $PSClusterNetWork
						$ClusterNetWorkInfoSection = New-Object PSObject
						Add-member -InputObject $ClusterNetWorkInfoSection -Membertype Noteproperty -Name $Psnetwork.Name -Value $PsClusterNetworkInfo
						$ClusterNetWorkName = $Psnetwork.Name
						$ClusterNetWorkCluster = $Psnetwork.Cluster
						$SectionName = "Cluster Networks – $ClusterNetWorkCluster"
						$ClusterNetWorkInfoSection | ConvertTo-Xml2 | update-diagreport -id  "06_$ClusterNetWorkName" -name $SectionName -verbosity informational -Description "Cluster Networks"
						Write-DiagProgress -activity $ClusterBasicInfo.ID_ClusterInfo -status "Cluster Network Information"
					}
				}

			}
			
			#   Win2K8 & 2003
			if ((Test-Path "HKLM:\Cluster") -and ($OSVersion.Build -lt 7600))
			{
				
				$CommandToRun = "`"" + $pwd.Path  + "\clusmps.exe`" /S /G /P:`"" + $pwd.Path + "`""
				$FileTocollect = $pwd.Path  + "\" + $Computername + "_cluster_mps_information.txt"
				$fileDescription = "Cluster Information"
				
				$x = Runcmd -commandToRun $CommandToRun -fileDescription $fileDescription -sectionDescription "Cluster Basic Information" -filesToCollect $FileTocollect -useSystemDiagnosticsObject
				
			}
			
		}
	}
}

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
